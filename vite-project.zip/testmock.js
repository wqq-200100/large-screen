import Mock from 'mockjs'
let data = Mock.mock({

})