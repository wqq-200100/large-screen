<template>
  <div class="container">
    <div class="main">
      <div class="main-title">
        <div demo-bg>
          <dv-border-box9>
            <div class="dv-bg" dv-bg>
              <!--<div class="title-text">哈哈哈哈哈</div>-->
              <div class="title-text center">政务云资源总览</div>
              <!--<div class="title-text">巴卡马卡把卡</div>-->
            </div>
          </dv-border-box9>
        </div>
      </div>
      <div class="main-table">
        <div v-for="item in tablesText" small-bg>
          <dv-decoration-11 style="width:200px;height:60px;color: white">
            <div bg="~ dark/0" color-green font-600>
              <div>{{ item }}</div>
            </div>
          </dv-decoration-11>
        </div>
      </div>

      <div class="main-content">
        <!--左边-->
        <div class="main-label">
          <div class="label-title">标题吃喜羊羊哈哈</div>
          <div class="main-label-table">
            <div v-for="item in mailable" class="table-item" @click="onchange">{{ item }}</div>
          </div>
          <el-pagination
              :total="50"
              background
              class="mt-4 bg"
              layout="prev, pager, next"
              small
          />
        </div>
        <!--中间-->
        <div class="main-statistics">
          <div class="ChartLabel">
            <div class="chartName">资源管理中心</div>
            <myCircle/>
            <!--            <div class="beeline-box">
                          <div class="cake cake-1">
                            <div class="beeline"></div>
                          </div>
                        </div>-->
          </div>
        </div>
        <!--右边-->
        <div class="main-label">
          <div class="label-title">标题吃喜羊羊哈哈</div>
          <div class="main-label-table">
            <div v-for="item in mailable" class="table-item">{{ item }}</div>
          </div>
          <el-pagination
              :total="50"
              background
              class="mt-4 bg"
              layout="prev, pager, next"
              small
          />
        </div>
      </div>
    </div>
    <div class="foot">
      <div class="zhu-zhuang-tu">
        <div class="label-title">表格</div>
        <div class="first-table">
          <el-table id="my-table" :data="tableData">
            <el-table-column prop="date" align="center" label="date" width="80"/>
            <el-table-column label="cpu" align="center">
              <el-table-column prop="cpu1" align="center" width="43"/>
              <el-table-column prop="cpu2" align="center" width="43"/>
            </el-table-column>
            <el-table-column label="gpu" align="center">
              <el-table-column prop="gpu1" align="center" width="43"/>
              <el-table-column prop="gpu2" align="center" width="43"/>
            </el-table-column>
            <el-table-column label="qbb" align="center">
              <el-table-column prop="qb1" align="center" width="43"/>
              <el-table-column prop="qb2" align="center" width="43"/>
            </el-table-column>
          </el-table>
        </div>
      </div>
      <div class="zhu-zhuang-tu" v-for="item in footTitle">
        <div class="label-title">{{ item.title }}</div>
        <myTable :colors="item.colors" :data="item.data" :name="item.name"/>
      </div>
    </div>
  </div>
</template>
<script setup>
import myTable from "./components/myTabel.vue";
import myCircle from "./components/myCircle.vue";
import {Random} from "mockjs";

const tablesText = $ref(['CJIA', 'ISQS', 'JSIQ', 'DXG', 'UIHXDU'])
const mailable = Array(14).fill(1).map(i=> Random.city() + '委办网')
const footTitle = $ref([
  {
    title: 'CPU',
    colors: [
      '#b186a1',
      '#664f97',
      '#584572'
    ],
    data: ["衬衫", "羊毛衫", "雪纺衫", "裤子", "高跟鞋", "袜子"],
    name: [198, 39, 55, 121, 55, 155]
  }, {
    title: 'CPU2',
    colors: [
      '#ceacb3',
      '#9a7b81',
      '#936886'
    ],
    data: ["吃饭", "是阿三", "和地区的", "裤i欧家栋i哦子", "嗲u好地方", "袜子"],
    name: [100, 83, 55, 121, 95, 222]
  }, {
    title: 'CPU3',
    colors: [
      'rgba(213,171,168,0.76)',
      '#f3796b',
      '#da4d61'
    ],
    data: ["高跟鞋", "羊毛衫", "雪纺衫", "裤子", "高跟鞋", "www"],
    name: [100, 33, 55, 121, 59, 123]
  },
])
const tableData = $ref([
  {
    date: '2022/10/23',
    cpu1: 222,
    cpu2: 333,
    gpu1: 9090,
    gpu2: 'ax',
    qb1: 300,
    qb2: 'ii',
  }, {
    date: '2022/10/24',
    cpu1: 44,
    cpu2: 77,
    gpu1: 1111,
    gpu2: 'ijd',
    qb1: 229,
    qb2: 'sd',
  }, {
    date: '2022/10/25',
    cpu1: 100,
    cpu2: 'kdx',
    gpu1: 999,
    gpu2: 90,
    qb1: 23,
    qb2: 399,
  }, {
    date: '2022/10/26',
    cpu1: '完全',
    cpu2: '胃口的',
    gpu1: '看完',
    gpu2: '几位',
    qb1: '等我',
    qb2: '开始',
  },
])

function onchange() {
  alert('000')
}

</script>

<style lang="scss" scoped>
::v-deep(#my-table .is-group tr:nth-child(2) ) {
  display: none;
}

.container {
  width: 100vw;
  height: 100vh;
  display: flex;
  flex-direction: column;
  background: rgb(10, 10, 30);

  .main {
    flex: 3;
    border: 2px solid rgb(6, 158, 224);


    .dv-bg {
      width: 100%;
      height: 100px;
      display: flex;
      justify-content: center;
      align-items: center;

      .title-text {
        padding: 0 22px;
        font-size: 23px;
        color: rgb(140, 144, 151);
      }

      .center {
        color: white;
        font-size: 33px;
      }
    }

    .main-table {
      display: flex;
      justify-content: space-around;
      margin-top: 27px;
    }

    .main-content {
      display: flex;
      justify-content: space-between;

      .main-label {
        margin-top: 20px;

        ::v-deep(.el-pagination) {
          margin: 60px 20px 9px;

          button, li {
            color: #fff;
            background: rgb(35, 56, 69);

            &.is-active {
              background: rgb(28, 131, 145);
            }
          }
        }

        .main-label-table {
          width: 200px;
          height: 280px;
          margin: 29px 30px 0;
          display: flex;
          align-content: flex-start;
          flex-flow: wrap;
          justify-content: space-between;

          .table-item {
            border: 2px solid rgb(6, 158, 224);
            border-radius: 5px;
            width: 94px;
            height: 33px;
            margin-bottom: 10px;
            color: white;
            line-height: 33px;
            text-align: center;
            font-size: 12px;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
          }
        }
      }

      .main-statistics {
        width: 350px;
        height: 350px;
        border: 10px solid rgb(13, 38, 74);
        border-radius: 50%;
        margin-top: 70px;
        position: relative;

        .ChartLabel {
          position: absolute;
          height: 100%;
          width: 100%;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          display: flex;
          justify-content: center;
          align-items: center;

          .chartName {
            color: #dddddd;
            margin-top: 10px;
            position: absolute;
          }

          .beeline-box {
            width: 350px;
            height: 350px;
            background: palegreen;
            position: absolute;
            top: 0;

            .cake {
              border: 1px solid orange;
            }
          }
        }
      }
    }
  }

  .foot {
    flex: 1;
    display: flex;
    flex-direction: row;
    justify-content: center;
    margin-top: 5px;
    overflow: hidden;

    .first-table {
      color: #fff;
      width: 90%;
      padding-left: 20px;
      margin-top: 8px;

      #my-table {
        width: 100%;
        height: 100%;
        margin-top: 19px
      }

      ::v-deep(.el-table .cell) {
        padding: 0 2px;
        line-height: 14px
      }

      ::v-deep(.el-table__body td.el-table__cell) {
        background: rgb(10, 10, 30);
        color: #fff;
        border: 1px solid #333
      }

      ::v-deep(.el-table thead.is-group th.el-table__cell) {
        background: rgb(10, 10, 30);
        color: #ddd;
        border: none;

      }

      ::v-deep(.el-table thead.is-group th.el-table__cell) {
        border-right: 1px solid #333 !important;
      }

    }

    .zhu-zhuang-tu {
      flex: 1;
      border: 2px solid rgb(6, 158, 224);
      margin-left: 5px;

      .label-title {
        font-size: 14px;
        margin-top: 5px;
      }

      .tubiao {
        width: 300px;
        height: 250px;
        margin-top: -38px;
        margin-left: 6px;
      }
    }
  }
}

.label-title {
  color: #fff;
  font-weight: 400;
  font-size: 16px;
  position: relative;
  margin-left: 20px;
  flex: 1;

  &:after {
    content: '';
    display: block;
    width: 6px;
    height: 16px;
    background: rgb(6, 255, 255);
    border-radius: 8px;
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    left: -12px;
  }
}
</style>
