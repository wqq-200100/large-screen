<template>
  <div class="container">
    <div class="main">
      <div class="main-title">
        <div demo-bg>
          <dv-border-box9>
            <div class="dv-bg" dv-bg>
              <div class="title-text">哈哈哈哈哈</div>
              <div class="title-text center">政务云资源总览</div>
              <div class="title-text">巴卡马卡把卡</div>
            </div>
          </dv-border-box9>
        </div>
      </div>
      <div class="main-table">
        <div v-for="item in tablesText" small-bg>
          <dv-decoration-11 style="width:200px;height:60px;color: white">
            <div bg="~ dark/0" color-green font-600>
              <div>{{ item }}</div>
            </div>
          </dv-decoration-11>
        </div>
      </div>

      <div class="main-content">
        <!--左边-->
        <div class="main-label">
          <div class="label-title">标题吃喜羊羊哈哈</div>
          <div class="main-label-table">
            <div v-for="item in mainlable" class="table-item">{{ item }}</div>
          </div>
          <el-pagination
              :total="50"
              background
              class="mt-4 bg"
              layout="prev, pager, next"
              small
          />
        </div>
        <div class="main-statistics"></div>
        <!--右边-->
        <div class="main-label">
          <div class="label-title">标题吃喜羊羊哈哈</div>
          <div class="main-label-table">
            <div v-for="item in mainlable" class="table-item">{{ item }}</div>
          </div>
          <el-pagination
              :total="50"
              background
              class="mt-4 bg"
              layout="prev, pager, next"
              small
          />
        </div>
      </div>
    </div>
    <div class="foot">
      <div class="zhu-zhuang-tu" v-for="item in footTitle">
        <div class="label-title">{{ item.title }}</div>
        <tabel :colors="item.colors"/>
      </div>
    </div>
  </div>
</template>
<script setup>
import {reactive} from "vue";
import Tabel from "./components/tabel.vue";

const tablesText = reactive(['CJIA', 'ISQS', 'JSIQ', 'DXG', 'UIHXDU'])
const footTitle = $ref([
  {
    title: 'CPU',
    colors:[
      '#06B5D7',
      '#44C0C1',
      '#71C8B1'
    ]
  },{
    title: 'CPU2',
    colors:[
      '#692bdc',
      '#692aac',
      '#692fff'
    ]
  },{
    title: 'CPU3',
    colors:[
      '#d7a306',
      '#c91f1f',
      '#d00000'
    ]
  },{
    title: 'CPU4',
    colors:[
      '#39fd53',
      '#19400b',
      '#064937'
    ]
  },
])
const mainlable = $ref(['数据1', '数据1', '数据1', '数据1', '数据1', '数据1', '数据1', '数据1', '数据1', '数据1', '数据1', '数据1'])

</script>

<style lang="scss" scoped>

.container {
  width: 100vw;
  height: 100vh;
  display: flex;
  flex-direction: column;
  background: rgb(10, 10, 30);

  .main {
    flex: 3;
    border: 2px solid rgb(6, 158, 224);

    .dv-bg {
      width: 100%;
      height: 100px;
      display: flex;
      justify-content: center;
      align-items: center;

      .title-text {
        padding: 0 22px;
        font-size: 23px;
        color: rgb(140, 144, 151);
      }

      .center {
        color: white;
        font-size: 33px;
      }
    }

    .main-table {
      display: flex;
      justify-content: space-around;
      margin-top: 35px;
    }

    .main-content {
      display: flex;
      justify-content: space-between;

      .main-label {
        margin-top: 20px;

        ::v-deep(.el-pagination) {
          margin-left: 19px;
          margin-bottom: 9px;

          button, li {
            color: #fff;
            background: rgb(35, 56, 69);

            &.is-active {
              background: rgb(28, 131, 145);
            }
          }
        }

        .main-label-table {
          width: 200px;
          height: 280px;
          margin: 10px 30px 0;
          display: flex;
          align-content: flex-start;
          flex-flow: wrap;
          justify-content: space-between;

          .table-item {
            border: 2px solid rgb(6, 158, 224);
            border-radius: 5px;
            width: 94px;
            height: 33px;
            margin-bottom: 10px;
            color: white;
            line-height: 33px;
            text-align: center;
            font-size: 12px;
          }
        }
      }

      .main-statistics {
        width: 300px;
        height: 300px;
        border: 2px solid rgb(6, 158, 224);
        border-radius: 50%;
        margin-top: 33px;
      }
    }
  }

  .foot {
    flex: 1;
    display: flex;
    flex-direction: row;
    justify-content: center;
    margin-top: 5px;
    overflow: hidden;

    .zhu-zhuang-tu {
      flex: 1;
      border: 2px solid rgb(6, 158, 224);
      margin-left: 5px;

      .label-title {
        font-size: 14px;
        margin-top: 5px;
      }

      .tubiao {
        width: 300px;
        height: 200px;
        margin-top: -38px;
        margin-left: 6px;
      }
    }
  }
}

.label-title {
  color: #fff;
  font-weight: 400;
  font-size: 16px;
  position: relative;
  margin-left: 20px;

  &:after {
    content: '';
    display: block;
    width: 6px;
    height: 16px;
    background: rgb(6, 255, 255);
    border-radius: 8px;
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    left: -12px;
  }
}
</style>
