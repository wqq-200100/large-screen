<template>
  <div class="circle-box">
    <div class="circle box-1">
      <div class="info">
        <div class="text">
          <p>上云系统数123个</p>
          <p>虚拟主机数123个</p>
        </div>
        <svg class="icon-yun" aria-hidden="true">
          <use xlink:href="#icon-a-tupianyihuifu-58"></use>
        </svg>
      </div>
    </div>
    <div class="circle box-2" :style="`transform: rotate(${72}deg)`">
      <div class="info">
        <div class="text">
          <p>写五个字哦123个</p>
          <p>写五个字哦123个</p>
        </div>
        <svg class="icon-yun" aria-hidden="true">
          <use xlink:href="#icon-a-tupianyihuifu-58"></use>
        </svg>
      </div>
    </div>
    <div class="circle box-3" :style="`transform: rotate(${72*2}deg)`">
      <div class="info">
        <div class="text">
          <p>写五个字哦123个</p>
          <p>写五个字哦123个</p>
        </div>
        <svg class="icon-yun" aria-hidden="true">
          <use xlink:href="#icon-a-tupianyihuifu-58"></use>
        </svg>
      </div>
    </div>
    <div class="circle box-4" :style="`transform: rotate(${72*3}deg)`">
      <div class="info">
        <div class="text">
          <p>写五个字哦123个</p>
          <p>写五个字哦123个</p>
        </div>
        <svg class="icon-yun" aria-hidden="true">
          <use xlink:href="#icon-a-tupianyihuifu-58"></use>
        </svg>
      </div>
    </div >
    <div class="circle box-5" :style="`transform: rotate(${72*4}deg)`">
      <div class="info">
        <div class="text">
          <p>写五个字哦123个</p>
          <p>写五个字哦123个</p>
        </div>
        <svg class="icon-yun" aria-hidden="true">
          <use xlink:href="#icon-a-tupianyihuifu-58"></use>
        </svg>
      </div>
    </div>
  </div>
</template>

<script>
const data = $ref({
  cloud:[21,44,21,48,99],
  fictitious:[21,44,21,48,99],
})

</script>

<style lang='scss' scoped>
.circle-box {
  width: 100%;
  height: 100%;

  .circle {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    transition: .5s;
    .info {
      position: absolute;
      left: 50%;
      top: -50%;
      transform: translate(-50%, 50%);

      .text {
        position: absolute;
        width: 100%;
        height: 100%;
        display: flex;
        justify-content: center;
        flex-direction: column;
        margin-top: 12px;

        p {
          font-size: 12px;
          text-align: center;
          margin: 0;
        }
      }

      svg {
        width: 100%;
      }
    }

    &.box-1 {
    }

    &.box-2 {
      //transform: rotate(120deg);

      .info {
        transform: translate(-50%, 50%) rotate(-120deg);
      }
    }

    &.box-3 {
      //transform: rotate(240deg);

      .info {
        transform: translate(-50%, 50%) rotate(-240deg);
      }
    }
  }
}
</style>
